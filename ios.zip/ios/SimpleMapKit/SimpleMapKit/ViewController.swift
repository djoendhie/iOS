//
//  ViewController.swift
//  SimpleMapKit
//
//  Created by Macbook Pro on 5/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

//adding the mapkit to our app
import MapKit

class ViewController: UIViewController,CLLocationManagerDelegate {

    @IBOutlet weak var myMap: MKMapView!
    
    // //declare varible
    var mygps = CLLocationManager()
    
    override func viewDidLoad() {
        
        //for our implement method
        mygps.delegate = self
        
        mygps.requestLocation()
        mygps.requestAlwaysAuthorization()
        
        super.viewDidLoad()

        //setting our lattitude and longitude
        //to find your current location just open your browser and search for "latlong"
        let coordinate = CLLocationCoordinate2D(latitude: -6.193758, longitude: 106.801614)
        
        let  spans = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        
        myMap.region = MKCoordinateRegion(center: coordinate, span: spans)
        
        //add a marker / PIN
        let marker = MKPointAnnotation()
        
        //the position of our marker/PIN
        marker.coordinate = coordinate
        
        //title of our marker/PIN
        marker.title = "Here I AM!!!"
        
        //annotation of our marker / pin
        myMap.addAnnotation(marker)
        //to make ormap movable and zoomable
        myMap.isZoomEnabled = true
        
        //to set the type of your map
        myMap.mapType = MKMapType.satellite
        
    }

    //add a func to uppdate your current map
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    }
    
    //add another func to give a print if your map fail to uppdate or cant be uppdated
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
    
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

