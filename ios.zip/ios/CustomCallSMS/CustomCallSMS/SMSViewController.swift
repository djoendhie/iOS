//
//  SMSViewController.swift
//  CustomCallSMS
//
//  Created by Macbook Pro on 5/31/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
//import for messaging
import MessageUI

class SMSViewController: UIViewController, MFMessageComposeViewControllerDelegate {

    @IBOutlet weak var tvNumber: UITextField!
    
    @IBOutlet weak var tvAdd: UITextField!
    @IBOutlet weak var tvMessage: UITextView!
    
    
    @IBAction func btnSMS(_ sender: Any) {
        //we add the coditonal when there`s no error
        
        
        if (MFMessageComposeViewController.canSendText()) {
            let sendd = MFMessageComposeViewController()
            //set the body of your message
            sendd.body = self.tvMessage.text
            //and the destination number
            sendd.recipients = [self.tvAdd.text!] + [self.tvNumber.text!]
//          tvNumber.text?.append("62")
            //delegate
            sendd.messageComposeDelegate = self
            
            //presenting it as an action
            self.present(sendd, animated: true, completion: nil)
            
        }
        else {
                //the conditional when there`s an error
            let alert = UIAlertView(title: "Error", message: "DONT KNOW", delegate: self, cancelButtonTitle: "OK")
            
            alert.show()
            
            print("error")
            
        }
        
        
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        
        controller.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
