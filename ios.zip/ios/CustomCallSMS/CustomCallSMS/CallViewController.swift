//
//  CallViewController.swift
//  CustomCallSMS
//
//  Created by Macbook Pro on 5/31/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class CallViewController: UIViewController {

    
    @IBOutlet weak var tvNumber: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnCall(_ sender: Any) {
        
        //creating the variable for phone number as the number that we type on the textfield
        
        var phoneNumber: NSURL = URL(string: "tel:" + self.tvNumber.text!) as! NSURL
        
        var error : NSError?
        
//
        //to set the action
        //the conditional when we meet an error
        if let err = error {
            print("ERRORRRRRR")
            
            // to show the alert dialog
            alertDialogs()
            
        }
        else {
            //the actionn when we dont have any errors
            
            UIApplication.shared.open(phoneNumber as URL, options: [:], completionHandler: nil)
        }
       
        
    }
    
    // showing an alert dialog for an error
    func alertDialogs() {
        let showAllert = UIAlertView(title: "Warning", message: "I DON`T KNOW", delegate: self, cancelButtonTitle: "OK")
        
        showAllert.show()
        
    }

}









