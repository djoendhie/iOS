//
//  Loan.swift
//  JSONTableView
//
//  Created by Macbook Pro on 5/28/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import Foundation

class Loan {
    
    var name: String = ""
    var country: String = ""
    var use: String = ""
    var amount: Int = 0
    
    
    
}
