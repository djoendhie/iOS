//
//  Loan.swift
//  ParsingDataJson
//
//  Created by Macbook pro on 01/11/17.
//  Copyright © 2017 Shin Corp. All rights reserved.
//

import Foundation

class Loan {
    
    var name: String = ""
    var country: String = ""
    var use: String = ""
    var amount: Int = 0
}
