//
//  DetailViewController.swift
//  SimpleGallery
//
//  Created by Macbook Pro on 5/25/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var detailImage: UIImageView!
    
    //variable for catching the mages
    var catchs : String? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // ! = it use whene the file that your gonna catch is already decided
        // ? = were still doesn`t know what kind of file were gonna catch
        
        //to change our var into images'
        detailImage.image = UIImage(named: catchs! + ".jpg")

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
