//
//  ViewController.swift
//  SimpleGallery
//
//  Created by Macbook Pro on 5/25/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

//adding a new implement method for our collection view
class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var myCollection: UICollectionView!
    
    //creating your array of images
    var myArray:[String] = ["1", "1","1","1", "1","1","2", "3", "3", "1", "2","2", "3", "1","1", "2", "3", "3", "1", "2","2", "3", "1", "1", "1","1","1", "1","1", "1", "1","1","1", "1","1","1", "1","1","1", "1","1","1", "1","1","1", "1","1","1", "1","1","1", "1","1", "1"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //custumizing the item size(images) ->width
        let itemSize = UIScreen.main.bounds.width/3 - 3
    
        //custumizing the layout
        let layout = UICollectionViewFlowLayout()
        
        layout.itemSize = CGSize(width: itemSize, height: itemSize)
        //margin between the images
        layout.sectionInset = UIEdgeInsetsMake(10, 0, 10, 0)
        
        // setting the minimum item spacing
        layout.minimumLineSpacing = 3
        layout.minimumInteritemSpacing = 3

        //its will add the layout that you just costumized into the collection view
        myCollection.collectionViewLayout = layout
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        //the number of item will depend on the total strings on it array
        return myArray.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        //declaring our cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath)as! CollectionViewCell
        
        //its use to shpw your image
        cell.myImage.image = UIImage(named: myArray[indexPath.row] + ".jpg")
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        //to move our controler to the detail
        // decide by the stryboard ID
        
        let story = UIStoryboard(name: "Main", bundle: Bundle.main)
        
        //taking the storyboard ID
        let idStory = story.instantiateViewController(withIdentifier: "DetailPass") as! DetailViewController
        
        //sending your data to the detailviewcontroller
        idStory.catchs = myArray[indexPath.row]
        
        //to perform the segue by identifier
        show(idStory, sender: self)
    }
}









