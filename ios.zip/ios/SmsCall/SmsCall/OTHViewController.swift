//
//  OTHViewController.swift
//  SmsCall
//
//  Created by Macbook Pro on 5/30/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import MessageUI

class OTHViewController: UIViewController, MFMessageComposeViewControllerDelegate {
    @IBOutlet weak var tfNumber: UITextField!
    @IBOutlet weak var tvISI: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Call(_ sender: Any) {
        var numersphoone:NSURL = URL(string: "tel:" + self.tfNumber.text!) as! NSURL
//        UIApplication.shared.openURL((NSURL(string: numersphoone)! as URL))
//        let num: NSURL = URL(string: "TEL://515123")! as NSURL
        UIApplication.shared.open(numersphoone as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func SMS(_ sender: Any) {
        if (MFMessageComposeViewController.canSendText()){
            let sendd = MFMessageComposeViewController()
            sendd.body = self.tvISI.text
            sendd.recipients = [self.tfNumber.text!]
            sendd.messageComposeDelegate = self
            
            self.present(sendd, animated: true, completion: nil)
        }else {
            print("error")
        }
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        self.dismiss(animated: true, completion: nil)
        
    }
    
}
