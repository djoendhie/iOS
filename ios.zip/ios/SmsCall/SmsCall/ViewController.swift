//
//  ViewController.swift
//  SmsCall
//
//  Created by Macbook Pro on 5/30/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import MessageUI
import Foundation

class ViewController: UIViewController, MFMessageComposeViewControllerDelegate, MFMailComposeViewControllerDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnCall(_ sender: Any) {
        let num: NSURL = URL(string: "TEL://515123")! as NSURL
        UIApplication.shared.open(num as URL, options: [:], completionHandler: nil)
    }
    
    
    
    @IBAction func btnSMS(_ sender: Any) {
        if MFMessageComposeViewController.canSendText() {
            let sendd = MFMessageComposeViewController()
            sendd.body = "Body.."
            sendd.recipients = ["12415"]
            sendd.messageComposeDelegate = self
            
            self.present(sendd, animated: true, completion: nil)
        }else {
            print("error")
        }
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        self.dismiss(animated: true, completion: nil)
        
    }
    
    
    @IBAction func btnEmail(_ sender: Any) {
        let mailcomposeViewController = configireMailComposeViewController()
        
        if MFMailComposeViewController.canSendMail() {
            self.present(mailcomposeViewController, animated: true, completion: nil)
        
        }else {
            self.showErrorAllert()
        }
        
    }
    func configireMailComposeViewController() -> MFMailComposeViewController{
        let mailComposer = MFMailComposeViewController()
        mailComposer.mailComposeDelegate = self
        mailComposer.setToRecipients(["ihaandjo@Gmail.com"])
        mailComposer.setSubject("subject")
        mailComposer.setMessageBody("body", isHTML: false)
        
        return mailComposer
    }
    
    func showErrorAllert() {
        let shoeErrorAller = UIAlertView(title: "allert", message: "cant", delegate: self, cancelButtonTitle: "OK")
        
        shoeErrorAller.show()
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
}












