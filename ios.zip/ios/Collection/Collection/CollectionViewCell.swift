//
//  CollectionViewCell.swift
//  Collection
//
//  Created by Macbook Pro on 5/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myImage: UIImageView!
}
