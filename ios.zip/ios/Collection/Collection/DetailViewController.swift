//
//  DetailViewController.swift
//  Collection
//
//  Created by Macbook Pro on 5/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.


import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var imView: UIImageView!
    
    var nmpung : String? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        
        imView.image = UIImage(named: nmpung! + ".jpg")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
