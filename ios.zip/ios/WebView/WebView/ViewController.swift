//
//  ViewController.swift
//  WebView
//
//  Created by Macbook Pro on 5/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        let myUrl = URL(string: "http://www.mangapark.net")
        
        myWebView.loadRequest(URLRequest(url: myUrl!))
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

