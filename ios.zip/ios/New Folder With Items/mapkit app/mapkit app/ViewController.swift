//
//  ViewController.swift
//  mapkit app
//
//  Created by Nando Septian Husni on 3/8/18.
//  Copyright © 2018 imastudio. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController,CLLocationManagerDelegate {
    @IBOutlet weak var map: MKMapView!
    
    
    //deklrasi variable
    var gps = CLLocationManager()
    
    
  //  var map = MKMapView()

    override func viewDidLoad() {
        
        gps.delegate = self
        
        gps.requestLocation()
        gps.requestAlwaysAuthorization()
        
        super.viewDidLoad()
        //tentukan coordinat
        //-6.1925297,106.8001397
        let coordinat  = CLLocationCoordinate2D(latitude: -6.1925297, longitude: 106.8001397)
        //zoom
        let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        
        map.region = MKCoordinateRegion(center: coordinat, span: span)
        
        //add pin in maps
        let pin = MKPointAnnotation()
        //posisi pin
        pin.coordinate = coordinat
        
        //title pin
        pin.title = "ini lokasi jakarta"
        
        
        map.addAnnotation(pin)
        //setting mapkit
        map.showsCompass  = true
        map.isZoomEnabled = true
    
        map.mapType = MKMapType.satellite
        
        
        
        
        
        
      
        //setting size maps

        
    
        
      //  view.addSubview(map)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //ngambil lokasi yg terupdate terrakhir
      let lokasiku =   locations.last?.coordinate
        

        map.centerCoordinate = lokasiku!
        
        //add pin in maps
        let pin = MKPointAnnotation()
        //posisi pin
        pin.coordinate = lokasiku!
        
        //title pin
        pin.title = "ini lokasiku"
        
        
        map.addAnnotation(pin)
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

