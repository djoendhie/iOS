//
//  CollectionViewCell.swift
//  Collectionview app
//
//  Created by Nando Septian Husni on 5/3/18.
//  Copyright © 2018 imastudio. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var itemImg: UIImageView!
}
