//
//  ViewController.swift
//  PickerImage
//
//  Created by Macbook Pro on 5/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var imView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnPicker(_ sender: Any) {
        //thi`ll be used to pick your image from galery or you can take your own picture using camera
        let picker = UIImagePickerController()
        picker.delegate = self
        
        //this will show tou the allert dialog to choose between camera or galery
        let alert = UIAlertController(title: "Choose", message: "Choose Your Image", preferredStyle: .alert)
        
        //this one if for taking your image from galery
        let gallery = UIAlertAction(title: "gallery", style: .default) { (act) in
            
            // chosing your image from gallery
            picker.sourceType = .photoLibrary
            
            //it`ll move you to your gallery
            self.present(picker,animated: true, completion: nil)
        }
        
        //this one is for taking your picture using camera
        let camera = UIAlertAction(title: "CAMERA", style: UIAlertActionStyle.default) { (act2) in
            
            //we`ll check is the camera available or not
            
            if UIImagePickerController.isSourceTypeAvailable(.camera){
                picker.sourceType = .camera
                
            self.present(picker,animated: true, completion: nil)
            }else{
                print("Camera Is not Available")
            }
        }
        //to give an action to your button
        alert.addAction(gallery)
        alert.addAction(camera)
        present(alert,animated: true, completion: nil)
    }
    
    //function to pick your images
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        //get the image that you choose....
        let myImage = info[UIImagePickerControllerOriginalImage]
        //itl set the imageView to the image that you just choose or take
        imView.image = (myImage as! UIImage)
        
        //dismissing our allert dialog
        picker.dismiss(animated: true, completion: nil)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

