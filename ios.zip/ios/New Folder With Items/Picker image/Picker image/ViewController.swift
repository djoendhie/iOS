//
//  ViewController.swift
//  Picker image
//
//  Created by Nando Septian Husni on 3/29/18.
//  Copyright © 2018 imastudio. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UIImagePickerControllerDelegate,UINavigationControllerDelegate{

    @IBOutlet weak var outlet: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func button(_ sender: Any) {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        
        let alert = UIAlertController(title: "Information", message: "choose image", preferredStyle: .alert)
        let ac1 = UIAlertAction(title: "gallery", style: .default) { (ac1) in
            
            picker.sourceType = .photoLibrary
            
            self.present(picker, animated: true, completion: nil)
            
        }
        let ac2 = UIAlertAction(title: "CAMERA", style: UIAlertActionStyle.default) { (ac2) in
            
            
            //check camera available apa enggak
            if UIImagePickerController.isSourceTypeAvailable(.camera){
             picker.sourceType = .camera
            self.present(picker, animated: true, completion: nil)
                
            }
            else{
                print("camera not available")
            }
        }
        
        alert.addAction(ac1)
        alert.addAction(ac2)
        present(alert, animated: true, completion: nil)
        
        
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        //get imge yang di take user
        let hasil = info[UIImagePickerControllerOriginalImage]
        
        outlet.image = (hasil as! UIImage)
        
        picker.dismiss(animated: true, completion: nil)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

