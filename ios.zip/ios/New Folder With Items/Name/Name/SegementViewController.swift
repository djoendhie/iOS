//
//  SegementViewController.swift
//  Name
//
//  Created by Macbook Pro on 5/23/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

var list = ["one", "two", "three"]

class SegementViewController: UIViewController {
    @IBOutlet weak var segemntOne: UISegmentedControl!
    @IBOutlet weak var imView: UIImageView!
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func segmentTwo(_ sender: Any) {

        
        //          manualy
//
//        if segemntOne.selectedSegmentIndex == 0 {
//            label.text = "Hello"
//        }
//        if segemntOne.selectedSegmentIndex == 1 {
//            label.text = "World"
//        }
//        if segemntOne.selectedSegmentIndex == 2{
//            label.text = "Hello World"
//        }
        
        
        // Using Switch case
        switch segemntOne.selectedSegmentIndex {
        case 0: label.text = "one"
            imView.image = UIImage(named: "one.jpg")
        case 1: label.text = "two"
            imView.image = UIImage(named: "two.jpg")
        case 2: label.text = "three"
            imView.image = UIImage(named: "three.jpg")
        default: label.text = "-_-"
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
