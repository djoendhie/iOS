//
//  ViewController.swift
//  Name
//
//  Created by Macbook Pro on 5/23/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //used when the button start is clicked and move to the -> MainNavController
    @IBAction func start(_ sender: Any) {
        let ViewController =
            storyboard?.instantiateViewController(withIdentifier: "MainNavController")as! MainNavController
         
        present(ViewController, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

