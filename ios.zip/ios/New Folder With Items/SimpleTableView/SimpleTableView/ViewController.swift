//
//  ViewController.swift
//  SimpleTableView
//
//  Created by Macbook Pro on 5/23/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {
    
    let list = ["Fruits", "Milk", "Honey", "Breed", "Fish", "Egg", "Chick"]
    let detail = [2, 1, 1, 5, 10, 15, 2]
    
    @IBOutlet weak var tabView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
//        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")

        let cell = tableView.dequeueReusableCell(withIdentifier: "cel")

        
        cell?.textLabel?.text = list[indexPath.row]
        //this one is use for int arrays
        cell?.detailTextLabel?.text = "\(detail[indexPath.row])"
        
        //this will be used when you use String
//        cell?.detailTextLabel?.text = detail[indexPath.row]
        
        return cell!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

