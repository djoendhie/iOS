//
//  TableViewController.swift
//  SimpleTableView
//
//  Created by Macbook Pro on 5/23/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

var city = ["jakarta", "surabaya", "solo", "Bali", "Bogor"]
var descs = ["jakerta is lovcated in indonesia its sooo full of trafic", "surabaya is somewhre in indonesia i guess it on west java", "solo located on mildle of java its soo hot in there", "Bali is a famouse place for a tourism its has such a beautiful beach and nice view", "its cold there"]
var myIndex = 0

class TableViewController: UITableViewController {

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return city.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        // Configure the cell...

        cell.textLabel?.text = city[indexPath.row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex = indexPath.row
        performSegue(withIdentifier: "move", sender: self)
    }

}
