//
//  TabViewController.swift
//  TableClick
//
//  Created by Macbook Pro on 5/23/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

class TabViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    let list = ["Milk", "Honey", "Breed"]
    let newl = [1, 2, 3]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
//thout detail
//        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        //detail
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        
        //detail
        cell?.textLabel?.text = list[indexPath.row]
        cell?.detailTextLabel?.text  = "\(newl[indexPath.row])"
    
        //non
        
//        cell?.textLabel?.text = list[indexPath.row]
        
        //detailde
        return cell!
        //return(cell)
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   

}
