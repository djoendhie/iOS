//
//  TableViewController.swift
//  TableClick
//
//  Created by Macbook Pro on 5/23/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

var pets = ["cat", "rabbit", "fish"]
var petdesc = ["cat  ", "rabbcat  2", "fish 3"]
var myIndex = 0

class TableViewController: UITableViewController {

   
    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return pets.count
    }

     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        // Configure the cell...

        cell.textLabel?.text = pets[indexPath.row]
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
        myIndex = indexPath.row
        performSegue(withIdentifier: "move", sender: self)
    }

}
