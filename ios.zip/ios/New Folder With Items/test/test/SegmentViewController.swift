//
//  SegmentViewController.swift
//  test
//
//  Created by chatrine on 23/05/18.
//  Copyright © 2018 chatrine. All rights reserved.
//

import UIKit

class SegmentViewController: UIViewController {
    @IBOutlet weak var segment: UISegmentedControl!
    
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func change(_ sender: Any) {
//        if segment.selectedSegmentIndex == 0 {
//            label.text = "Hello"
//        }
//        if segment.selectedSegmentIndex == 1 {
//            label.text = "World"
//        }
//        if segment.selectedSegmentIndex == 2 {
//            label.text = "This Is ME!!"
//        }
        
        switch segment.selectedSegmentIndex {
        case 0: label.text = "one"
        case 1: label.text = "two"
        case 2: label.text = "three"
        default: label.text = "-_-"
        }
    }
    
}
