//
//  MainNavController.swift
//  test
//
//  Created by chatrine on 22/05/18.
//  Copyright © 2018 chatrine. All rights reserved.
//

import Foundation
import UIKit

class MainNavController: UINavigationController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
