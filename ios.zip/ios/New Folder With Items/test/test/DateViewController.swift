//
//  DateViewController.swift
//  test
//
//  Created by chatrine on 23/05/18.
//  Copyright © 2018 chatrine. All rights reserved.
//

import UIKit

class DateViewController: UIViewController {

    @IBOutlet weak var txt: UILabel!
    
    @IBOutlet weak var pick: UIDatePicker!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func get(_ sender: Any) {
        txt.text = "\(pick.date)"
    }
    
    //        txt.text = "\(picker.date)"


}
