//
//  ViewController.swift
//  test
//
//  Created by chatrine on 22/05/18.
//  Copyright © 2018 chatrine. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func login(_ sender: Any) {
        let zzViewController = storyboard?.instantiateViewController(withIdentifier: "MainNavController")as! MainNavController
        
        present(zzViewController, animated: true, completion: nil)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

