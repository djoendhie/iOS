//
//  zzViewController.swift
//  test
//
//  Created by chatrine on 22/05/18.
//  Copyright © 2018 chatrine. All rights reserved.
//

import UIKit

class zzViewController: UIViewController {

    @IBOutlet weak var yes: UILabel!
    
    @IBAction func chose(_ sender: UISwitch) {
        if (sender.isOn == true){
            yes.text = "Yes I Want Pizza!"
        }else{
            yes.text = "No I Dont WAnt Pizza!"
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func logout(_ sender: Any) {
        presentingViewController?.dismiss(animated: true
        , completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
