//
//  ViewController.swift
//  SimpleVideoPlayer
//
//  Created by Macbook Pro on 5/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
//add a new import for media player
import AVFoundation
//import to show the video
import AVKit

class ViewController: UIViewController {
    
    //variable for our media player
    var player : AVPlayer? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //source of our video
        let video = Bundle.main.path(forResource: "video", ofType: "mp4")
        
        // to embed the video with the source
        player = AVPlayer(url: URL(fileURLWithPath: video!))
        
    }

    @IBAction func btnPlay(_ sender: Any) {
        //its a func to make you can play your video + showing its
        let playVideo = AVPlayerViewController()
        playVideo.player = player
        
        //display our player
        present(playVideo, animated: true) {
            self.player?.play()
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

