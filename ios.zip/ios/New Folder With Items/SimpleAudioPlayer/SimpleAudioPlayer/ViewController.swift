//
//  ViewController.swift
//  SimpleAudioPlayer
//
//  Created by Macbook Pro on 5/24/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    //declarating audio player
    var audio : AVAudioPlayer? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        do{
            //set the source of your audio
            let mySource = Bundle.main.path(forResource: "audio", ofType: "mp3")
            
            // putting your audio into the audio player
            try audio = AVAudioPlayer(contentsOf: URL(fileURLWithPath: mySource!))
        }catch{
            print("audio Error")
        }
        
    }

    @IBAction func btnPlay(_ sender: Any) {
        // it`ll use to set your button to play the audio
        audio?.play()
        
        //this will let the system know the duration of your audio
        let time = audio?.duration
        let hour = time!/3600
        let minute = hour/60
        
        print(hour)
        print(minute)
    }
    
    @IBAction func btnStop(_ sender: Any) {
        //to stop your audio
        audio?.stop()
    }
    
    @IBAction func btnPause(_ sender: Any) {
        //to pause your audio
        audio?.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

