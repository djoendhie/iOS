//
//  ViewController.swift
//  CustomTableView
//
//  Created by Macbook Pro on 5/23/18.
//  Copyright © 2018 Macbook Pro. All rights reserved.
//

import UIKit

  var city = ["jakarta", "surabaya", "bogor", "bali", "solo"]


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.delegate = self
        tableView.dataSource = self
    }

    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return city.count
    }
    
    // to costumize your tableViewCell Height
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "customCell")as! TableViewCell
        
        cell.label.text = city[indexPath.row]
        cell.picture.image = UIImage(named: city[indexPath.row])
        return cell
    }


}

